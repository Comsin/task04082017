(function ( $ ) {
	"use strict";

	$(function () {

		// Place your administration-specific JavaScript here

	});

}(jQuery));